const e={id:"ID",phase_code:"学段",phase_name:"学段名",update_time:"修改时间",create_time:"创建时间","quick Search Fields":"ID"};export{e as default};
