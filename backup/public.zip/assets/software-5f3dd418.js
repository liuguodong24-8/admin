const e={id:"id",version_code:"version_code",version_name:"version_name",file_url:"file_url",create_time:"create_time","quick Search Fields":"id"};export{e as default};
