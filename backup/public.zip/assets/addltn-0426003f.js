const d={id:"id",addr:"addr",addr_ltn:"addr_ltn",add_id:"add_id","quick Search Fields":"id"};export{d as default};
