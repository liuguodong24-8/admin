const d={id:"ID",addr:"学校名称",addr_ltn:"具体经纬度",add_id:"标识ID","quick Search Fields":"ID"};export{d as default};
