const t={id:"id",title:"title",content:"content",picture:"picture",update_time:"update_time",create_time:"create_time","quick Search Fields":"id"};export{t as default};
