const e={id:"ID",version_code:"包名",version_name:"版本号展示",file_url:"软件app",create_time:"创建时间","quick Search Fields":"ID"};export{e as default};
