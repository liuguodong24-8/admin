import{a4 as f}from"./index-f72766ad.js";const n=(i,e,r)=>["gif","jpg","jpeg","bmp","png","webp"].includes(r)?i.full_url:f(r);export{n as p};
