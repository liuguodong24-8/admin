const e={id:"ID",activity_id:"远程下拉",activity__act_name:"活动标题",dev_id:"远程下拉",dev__user_name:"学生姓名",create_time:"创建时间","quick Search Fields":"ID"};export{e as default};
