const s="/assets/logo-6e782b9c.png";export{s as _};
