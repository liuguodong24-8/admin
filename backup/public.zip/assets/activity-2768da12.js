const t={id:"id",act_name:"act_name",act_cont:"act_cont",update_time:"update_time",create_time:"create_time","quick Search Fields":"id"};export{t as default};
