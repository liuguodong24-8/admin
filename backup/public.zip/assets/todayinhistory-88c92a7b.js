const t={id:"ID",title:"标题",content:"内容",picture:"图片",update_time:"修改时间",create_time:"创建时间","quick Search Fields":"ID"};export{t as default};
