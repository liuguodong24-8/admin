const e={id:"id",activity_id:"activity_id",activity__act_name:"act_name",dev_id:"dev_id",dev__user_name:"user_name",create_time:"create_time","quick Search Fields":"id"};export{e as default};
