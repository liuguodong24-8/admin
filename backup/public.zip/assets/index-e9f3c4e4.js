import{a4 as f}from"./index-a6f6b7ce.js";const n=(i,e,r)=>["gif","jpg","jpeg","bmp","png","webp"].includes(r)?i.full_url:f(r);export{n as p};
