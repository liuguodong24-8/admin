const e={id:"id",grade_code:"grade_code",grade_name:"grade_name",update_time:"update_time",create_time:"create_time","quick Search Fields":"id"};export{e as default};
