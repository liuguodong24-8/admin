const o={GroupName:"Group name","Group name":"Group name",jurisdiction:"Permissions"};export{o as default};
