const e={id:"ID",admin_id:"教师ID-管理员ID",admin__username:"用户名",admin__nickname:"昵称",teacher_id_card_no:"教师证件号",update_time:"修改时间",create_time:"创建时间","quick Search Fields":"ID"};export{e as default};
