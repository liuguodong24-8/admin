const e={id:"ID",act_name:"活动标题",act_cont:"活动内容",dev__user_name:"学生姓名",update_time:"修改时间",create_time:"创建时间","quick Search Fields":"ID"};export{e as default};
