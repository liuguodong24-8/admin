import{a4 as f}from"./index-764fcd0d.js";const n=(i,e,r)=>["gif","jpg","jpeg","bmp","png","webp"].includes(r)?i.full_url:f(r);export{n as p};
