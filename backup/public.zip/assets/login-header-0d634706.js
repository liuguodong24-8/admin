const s="/assets/login-header-2b702f97.png";export{s as _};
