const e={"Please enter an account":"请输入账号","Please input a password":"请输入密码","Hold session":"保持会话","Sign in":"登录"};export{e as default};
