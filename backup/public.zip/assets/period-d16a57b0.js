const e={id:"id",phase_code:"phase_code",phase_name:"phase_name",update_time:"update_time",create_time:"create_time","quick Search Fields":"id"};export{e as default};
