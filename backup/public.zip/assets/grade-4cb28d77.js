const e={id:"ID",grade_code:"年级",grade_name:"年级名称",update_time:"修改时间",create_time:"创建时间","quick Search Fields":"ID"};export{e as default};
